#!/bin/sh

java -Djava.library.path=./x64 -jar JNIDemo.jar
